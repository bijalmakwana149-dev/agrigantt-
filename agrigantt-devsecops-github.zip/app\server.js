/**
 * AgriGantt - DevSecOps CIAP Microproject
 * Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System
 * Aligned with UN SDG 9: Industry, Innovation, and Infrastructure
 */

const express = require('express');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Security Middleware (DevSecOps Best Practices)
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https://*"],
      connectSrc: ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));

app.use(cors());
app.use(express.json({ limit: '10kb' })); // Mitigate Denial of Service from payload flooding
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Static Assets
app.use(express.static(path.join(__dirname, 'public')));

// In-Memory Database for Project Tasks (IoT Smart Agriculture Project Lifecycle)
let tasks = [
  {
    id: "TSK-101",
    name: "Farm Topography & LoRaWAN Gateway Mesh Survey",
    phase: "Phase 1: Architecture & Network",
    category: "Network",
    startDate: "2026-10-01",
    endDate: "2026-10-06",
    progress: 100,
    status: "Completed",
    assignee: "Dr. Evelyn Reed",
    role: "IoT Systems Architect",
    priority: "High",
    dependencies: [],
    isMilestone: false,
    iotTarget: "LoRaWAN 868MHz Mesh GW-01 & GW-02"
  },
  {
    id: "TSK-102",
    name: "Milestone: Wireless LoRaWAN Mesh Base Station Live",
    phase: "Phase 1: Architecture & Network",
    category: "Milestone",
    startDate: "2026-10-06",
    endDate: "2026-10-06",
    progress: 100,
    status: "Completed",
    assignee: "Marcus Vance",
    role: "DevSecOps Engineer",
    priority: "Critical",
    dependencies: ["TSK-101"],
    isMilestone: true,
    iotTarget: "Central Tower Gateway"
  },
  {
    id: "TSK-103",
    name: "Deploy 50 Soil Moisture (FDR) & Soil Temp Sensor Nodes",
    phase: "Phase 2: Sensing Infrastructure",
    category: "Sensors",
    startDate: "2026-10-07",
    endDate: "2026-10-14",
    progress: 85,
    status: "In Progress",
    assignee: "Rohan Patel",
    role: "Embedded Hardware Specialist",
    priority: "High",
    dependencies: ["TSK-102"],
    isMilestone: false,
    iotTarget: "Sectors A1-A5 & B1-B5 Nodes"
  },
  {
    id: "TSK-104",
    name: "Install Optical NPK (Nitrogen-Phosphorus-Potassium) Probes",
    phase: "Phase 2: Sensing Infrastructure",
    category: "Sensors",
    startDate: "2026-10-10",
    endDate: "2026-10-17",
    progress: 60,
    status: "In Progress",
    assignee: "Dr. Evelyn Reed",
    role: "Precision Agronomist",
    priority: "Medium",
    dependencies: ["TSK-103"],
    isMilestone: false,
    iotTarget: "Soil Chemistry Probe Grid"
  },
  {
    id: "TSK-105",
    name: "Autonomous Solar-Powered Drip Irrigation Solenoid Actuators",
    phase: "Phase 3: Actuation & Control",
    category: "Actuation",
    startDate: "2026-10-15",
    endDate: "2026-10-22",
    progress: 40,
    status: "In Progress",
    assignee: "Sarah Jenkins",
    role: "Farm Operations Lead",
    priority: "Critical",
    dependencies: ["TSK-104"],
    isMilestone: false,
    iotTarget: "Zones 1-4 Motorized Valves"
  },
  {
    id: "TSK-106",
    name: "Milestone: Closed-Loop Automated Fertigation Verification",
    phase: "Phase 3: Actuation & Control",
    category: "Milestone",
    startDate: "2026-10-22",
    endDate: "2026-10-22",
    progress: 25,
    status: "Planned",
    assignee: "Sarah Jenkins",
    role: "Farm Operations Lead",
    priority: "High",
    dependencies: ["TSK-105"],
    isMilestone: true,
    iotTarget: "Fertigation Dosing Unit"
  },
  {
    id: "TSK-107",
    name: "Multispectral Drone Imagery Integration (NDVI Indexing)",
    phase: "Phase 4: Aerial Analytics",
    category: "Analytics",
    startDate: "2026-10-23",
    endDate: "2026-10-28",
    progress: 10,
    status: "Planned",
    assignee: "Rohan Patel",
    role: "Drone Pilot & GIS Analyst",
    priority: "Medium",
    dependencies: ["TSK-106"],
    isMilestone: false,
    iotTarget: "DJI Matrice Multispectral Rig"
  },
  {
    id: "TSK-108",
    name: "DevSecOps Pipeline Hardening & SonarQube / Trivy Scan Gate",
    phase: "Phase 5: Cloud & DevSecOps",
    category: "DevSecOps",
    startDate: "2026-10-12",
    endDate: "2026-10-25",
    progress: 90,
    status: "In Progress",
    assignee: "Marcus Vance",
    role: "DevSecOps Engineer",
    priority: "Critical",
    dependencies: ["TSK-101"],
    isMilestone: false,
    iotTarget: "Jenkins CI/CD + AWS Terraform"
  },
  {
    id: "TSK-109",
    name: "Milestone: Production Zero-Vulnerability Release on AWS",
    phase: "Phase 5: Cloud & DevSecOps",
    category: "Milestone",
    startDate: "2026-10-28",
    endDate: "2026-10-28",
    progress: 0,
    status: "Planned",
    assignee: "Marcus Vance",
    role: "DevSecOps Engineer",
    priority: "Critical",
    dependencies: ["TSK-107", "TSK-108"],
    isMilestone: true,
    iotTarget: "AWS EC2 Production Fleet"
  }
];

// In-Memory Collaboration Activity Feed
let activities = [
  {
    id: 1,
    user: "Marcus Vance",
    role: "DevSecOps Engineer",
    action: "Configured Jenkins Quality Gate with SonarQube & Trivy scan step",
    timestamp: "2026-10-15 11:45:10",
    badge: "Security"
  },
  {
    id: 2,
    user: "Dr. Evelyn Reed",
    role: "Precision Agronomist",
    action: "Updated moisture threshold parameters for Sector B3 Tomato plot",
    timestamp: "2026-10-15 11:20:00",
    badge: "IoT Telemetry"
  },
  {
    id: 3,
    user: "Rohan Patel",
    role: "Embedded Hardware Specialist",
    action: "Completed calibration for FDR soil moisture node cluster #4",
    timestamp: "2026-10-15 10:15:32",
    badge: "Hardware"
  },
  {
    id: 4,
    user: "Sarah Jenkins",
    role: "Farm Operations Lead",
    action: "Approved Irrigation Work Package schedule change for Zone 2",
    timestamp: "2026-10-15 09:30:15",
    badge: "Schedule"
  }
];

// Simulated IoT Field Nodes Telemetry
const iotNodes = [
  { id: "NODE-SM-01", sector: "Sector A (Wheat)", type: "Soil Moisture (FDR)", value: "37.8 %", temp: "23.4 °C", battery: "96%", status: "Optimal", lastPing: "Just now" },
  { id: "NODE-SM-02", sector: "Sector B (Corn)", type: "Soil Moisture (FDR)", value: "29.2 %", temp: "25.1 °C", battery: "92%", status: "Low Moisture", lastPing: "1m ago" },
  { id: "NODE-NPK-01", sector: "Sector C (Soybean)", type: "NPK Sensor Probe", value: "N:45 P:22 K:60 mg/kg", temp: "22.8 °C", battery: "89%", status: "Optimal", lastPing: "2m ago" },
  { id: "NODE-GW-868", sector: "Central Base Tower", type: "LoRaWAN 868MHz Gateway", value: "Packets: 18,450 / SNR: +9.2dB", temp: "31.2 °C", battery: "Solar Mains", status: "Active Mesh", lastPing: "Live" },
  { id: "VALVE-ACT-04", sector: "Irrigation Substation 2", type: "Precision Solenoid Valve", value: "Flow: 14.2 L/min (Active)", temp: "26.0 °C", battery: "24V Solar", status: "Irrigating", lastPing: "Live" }
];

// DevSecOps Audit Metrics
const devSecOpsAudit = {
  project: "Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System",
  sdgAlignment: "SDG 9: Industry, Innovation, and Infrastructure",
  sdgTargets: [
    "Target 9.1: Develop quality, reliable, sustainable and resilient infrastructure",
    "Target 9.4: Upgrade infrastructure and retrofit industries to make them sustainable",
    "Target 9.5: Enhance scientific research and upgrade technological capabilities"
  ],
  sonarQube: {
    status: "PASSED",
    bugs: 0,
    vulnerabilities: 0,
    securityHotspots: 0,
    codeSmells: 2,
    codeSmellsResolved: 2,
    testCoverage: "92.4%",
    duplications: "0.0%",
    maintainabilityRating: "A",
    securityRating: "A"
  },
  trivyScan: {
    scanTarget: "agrigantt-app:latest (Node:20-alpine)",
    vulnerabilitiesDetected: 0,
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    status: "PASSED (Clean Container)",
    baseImage: "node:20-alpine (Distroless-ready non-root runtime)"
  },
  infrastructure: {
    provider: "AWS Cloud (via Terraform)",
    resources: ["aws_vpc", "aws_subnet", "aws_internet_gateway", "aws_route_table", "aws_security_group", "aws_instance"],
    leastPrivilegeSecGroup: "Inbound: Port 80 (HTTP), Port 443 (HTTPS), Port 22 (SSH Admin CIDR only)",
    orchestration: "Jenkins Declarative Multi-stage Pipeline"
  }
};

/* ==========================================================
   REST API Endpoints
   ========================================================== */

// 1. Health Check (Vital for Docker & AWS Deployment Monitoring)
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    service: 'AgriGantt IoT Smart Agriculture DevSecOps Core',
    environment: process.env.NODE_ENV || 'production'
  });
});

// 2. Get All Tasks
app.get('/api/tasks', (req, res) => {
  res.status(200).json({
    success: true,
    total: tasks.length,
    data: tasks
  });
});

// 3. Add New Task (Sanitized)
app.post('/api/tasks', (req, res) => {
  const { name, phase, category, startDate, endDate, progress, status, assignee, role, priority, dependencies, isMilestone, iotTarget } = req.body;
  
  if (!name || !startDate || !endDate) {
    return res.status(400).json({ success: false, error: 'Task name, start date, and end date are required.' });
  }

  const newTask = {
    id: `TSK-${Date.now().toString().slice(-4)}`,
    name: String(name).slice(0, 100),
    phase: phase || "Phase 2: Sensing Infrastructure",
    category: category || "General",
    startDate,
    endDate,
    progress: Number(progress) || 0,
    status: status || "Planned",
    assignee: assignee || "Agricultural Specialist",
    role: role || "Contributor",
    priority: priority || "Medium",
    dependencies: Array.isArray(dependencies) ? dependencies : [],
    isMilestone: Boolean(isMilestone),
    iotTarget: iotTarget || "Field Node"
  };

  tasks.push(newTask);

  // Add activity log
  activities.unshift({
    id: Date.now(),
    user: newTask.assignee,
    role: newTask.role,
    action: `Created new work package item "${newTask.name}"`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    badge: "Planning"
  });

  res.status(201).json({ success: true, data: newTask });
});

// 4. Update Task
app.put('/api/tasks/:id', (req, res) => {
  const { id } = req.params;
  const index = tasks.findIndex(t => t.id === id);

  if (index === -1) {
    return res.status(404).json({ success: false, error: 'Task not found.' });
  }

  const updatedTask = { ...tasks[index], ...req.body };
  tasks[index] = updatedTask;

  activities.unshift({
    id: Date.now(),
    user: req.body.updatedBy || updatedTask.assignee,
    role: req.body.role || updatedTask.role,
    action: `Updated task [${updatedTask.id}] "${updatedTask.name}" to ${updatedTask.progress}% (${updatedTask.status})`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    badge: "Progress"
  });

  res.status(200).json({ success: true, data: updatedTask });
});

// 5. Delete Task
app.delete('/api/tasks/:id', (req, res) => {
  const { id } = req.params;
  const index = tasks.findIndex(t => t.id === id);

  if (index === -1) {
    return res.status(404).json({ success: false, error: 'Task not found.' });
  }

  const removed = tasks.splice(index, 1)[0];

  activities.unshift({
    id: Date.now(),
    user: "Project Lead",
    role: "Administrator",
    action: `Archived/Removed task [${id}] "${removed.name}"`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    badge: "Archived"
  });

  res.status(200).json({ success: true, message: `Task ${id} deleted successfully.` });
});

// 6. IoT Telemetry Node Status
app.get('/api/iot-nodes', (req, res) => {
  res.status(200).json({ success: true, count: iotNodes.length, data: iotNodes });
});

// 7. Collaboration Activities Feed
app.get('/api/collaborate/activities', (req, res) => {
  res.status(200).json({ success: true, count: activities.length, data: activities.slice(0, 20) });
});

// 8. Add Collaborative Message / Comment
app.post('/api/collaborate/comment', (req, res) => {
  const { user, role, comment, badge } = req.body;
  if (!comment) {
    return res.status(400).json({ success: false, error: 'Comment text is required.' });
  }

  const entry = {
    id: Date.now(),
    user: user || "Team Member",
    role: role || "Contributor",
    action: String(comment).slice(0, 200),
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    badge: badge || "Collaboration"
  };

  activities.unshift(entry);
  res.status(201).json({ success: true, data: entry });
});

// 9. DevSecOps & SDG 9 Audit Information
app.get('/api/security/audit', (req, res) => {
  res.status(200).json({ success: true, data: devSecOpsAudit });
});

// Wildcard fallback to SPA index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Graceful Shutdown & Export for Testing
let server;
if (require.main === module) {
  server = app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(` AgriGantt IoT Smart Agriculture Server is running`);
    console.log(` Port: ${PORT}`);
    console.log(` Health Check: http://localhost:${PORT}/api/health`);
    console.log(` Web UI: http://localhost:${PORT}`);
    console.log(` DevSecOps SDG 9 Alignment: Active`);
    console.log(`=======================================================`);
  });
}

process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  if (server) {
    server.close(() => {
      console.log('HTTP server closed cleanly');
    });
  }
});

module.exports = { app };
