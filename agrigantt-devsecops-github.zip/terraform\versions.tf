# ==============================================================================
# Terraform Version and Provider Requirements
# ==============================================================================

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # In production, state is securely locked in S3 with DynamoDB state locking
  # backend "s3" {
  #   bucket         = "agrigantt-terraform-state-bucket"
  #   key            = "prod/agrigantt/terraform.tfstate"
  #   region         = "us-east-1"
  #   dynamodb_table = "agrigantt-tf-state-lock"
  #   encrypt        = true
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "AgriGantt-IoT-SmartAgriculture"
      Course      = "DevSecOps-Lab-CIAP"
      Environment = var.environment
      SDG         = "SDG-9-Industry-Innovation-Infrastructure"
      ManagedBy   = "Terraform"
    }
  }
}
