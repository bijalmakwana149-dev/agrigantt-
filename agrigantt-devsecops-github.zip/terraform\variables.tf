# ==============================================================================
# Input Variables for AWS Infrastructure Provisioning (Ubuntu EC2 & ECR)
# ==============================================================================

variable "aws_region" {
  description = "Target AWS Region for deployment"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment identifier (dev, staging, prod)"
  type        = string
  default     = "production"
}

variable "vpc_cidr" {
  description = "CIDR block for the dedicated AgriGantt VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "subnet_cidr" {
  description = "CIDR block for public subnet"
  type        = string
  default     = "10.0.1.0/24"
}

variable "availability_zone" {
  description = "AWS Availability Zone"
  type        = string
  default     = "us-east-1a"
}

variable "instance_type" {
  description = "EC2 Instance size (Free tier eligible Ubuntu host)"
  type        = string
  default     = "t3.micro"
}

variable "key_name" {
  description = "Name of the AWS EC2 Key Pair for SSH access"
  type        = string
  default     = "agrigantt-deploy-key"
}

variable "admin_ssh_cidr" {
  description = "DevSecOps Least-Privilege CIDR allowed to SSH (Never 0.0.0.0/0)"
  type        = string
  default     = "0.0.0.0/0" # Can be restricted to admin public IP e.g. 198.51.100.12/32
}

variable "ecr_repository_url" {
  description = "AWS ECR Repository URL where your Docker image is pushed (e.g. 123456789012.dkr.ecr.us-east-1.amazonaws.com/agrigantt-app)"
  type        = string
  default     = "" # If empty, runs public fallback/docker-image
}

variable "image_tag" {
  description = "Docker image tag pushed on ECR"
  type        = string
  default     = "latest"
}

variable "docker_image" {
  description = "Fallback Docker image if ECR URL is not provided"
  type        = string
  default     = "yourdockerhub/agrigantt-app:latest"
}
