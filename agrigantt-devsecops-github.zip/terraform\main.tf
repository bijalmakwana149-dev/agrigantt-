# ==============================================================================
# Main Infrastructure Configuration (AWS)
# Provisions VPC, Subnet, Internet Gateway, Security Group, IAM, and Ubuntu EC2
# Configures Docker CLI, ECR Authentication, and runs Containerized AgriGantt
# ==============================================================================

# 1. Dynamic query to locate official Canonical Ubuntu 22.04 LTS (Jammy) AMI
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical Official AWS Owner ID

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# 2. Dedicated Virtual Private Cloud (VPC)
resource "aws_vpc" "agrigantt_vpc" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "agrigantt-dedicated-vpc"
  }
}

# 3. Internet Gateway (IGW) for Inbound/Outbound Connectivity
resource "aws_internet_gateway" "agrigantt_igw" {
  vpc_id = aws_vpc.agrigantt_vpc.id

  tags = {
    Name = "agrigantt-internet-gateway"
  }
}

# 4. Public Subnet
resource "aws_subnet" "agrigantt_public_subnet" {
  vpc_id                  = aws_vpc.agrigantt_vpc.id
  cidr_block              = var.subnet_cidr
  availability_zone       = var.availability_zone
  map_public_ip_on_launch = true

  tags = {
    Name = "agrigantt-public-subnet"
  }
}

# 5. Route Table & Internet Route
resource "aws_route_table" "agrigantt_public_rt" {
  vpc_id = aws_vpc.agrigantt_vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.agrigantt_igw.id
  }

  tags = {
    Name = "agrigantt-public-route-table"
  }
}

# 6. Route Table Association
resource "aws_route_table_association" "agrigantt_rta" {
  subnet_id      = aws_subnet.agrigantt_public_subnet.id
  route_table_id = aws_route_table.agrigantt_public_rt.id
}

# 7. DevSecOps Hardened Security Group
resource "aws_security_group" "agrigantt_sg" {
  name        = "agrigantt-ubuntu-web-sg"
  description = "Security rules for AgriGantt IoT platform on Ubuntu EC2"
  vpc_id      = aws_vpc.agrigantt_vpc.id

  # Inbound HTTP (Standard Web Port 80)
  ingress {
    description = "Allow inbound HTTP web traffic"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # Inbound Direct Application Port (Port 3000)
  ingress {
    description = "Allow direct Node.js application traffic on port 3000"
    from_port   = 3000
    to_port     = 3000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # Inbound HTTPS (Port 443)
  ingress {
    description = "Allow inbound HTTPS traffic"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # Inbound SSH (Port 22)
  ingress {
    description = "Administrator SSH Access"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.admin_ssh_cidr]
  }

  # Outbound All Traffic (Allows pulling Docker images from AWS ECR & OS updates)
  egress {
    description = "Allow all outbound traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "agrigantt-firewall-rules"
  }
}

# 8. IAM Role & Instance Profile for Secure AWS ECR Authentication
resource "aws_iam_role" "ec2_ecr_role" {
  name = "agrigantt-ec2-ecr-read-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "ecr_policy_attach" {
  role       = aws_iam_role.ec2_ecr_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

resource "aws_iam_instance_profile" "ec2_profile" {
  name = "agrigantt-ec2-instance-profile"
  role = aws_iam_role.ec2_ecr_role.name
}

# 9. AWS EC2 Virtual Machine Instance (Ubuntu 22.04 LTS)
resource "aws_instance" "agrigantt_ec2" {
  ami                         = data.aws_ami.ubuntu.id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.agrigantt_public_subnet.id
  vpc_security_group_ids      = [aws_security_group.agrigantt_sg.id]
  iam_instance_profile        = aws_iam_instance_profile.ec2_profile.name
  associate_public_ip_address = true
  key_name                    = var.key_name != "" ? var.key_name : null

  # Cloud-Init User Data: Installs Docker CLI, logs into ECR, pulls image, runs container
  user_data = <<-EOF
              #!/bin/bash
              set -e
              exec > >(tee /var/log/user_data.log|logger -t user-data -s 2>/dev/console) 2>&1

              echo "=== [1/5] Updating Ubuntu Repositories & Packages ==="
              apt-get update -y
              DEBIAN_FRONTEND=noninteractive apt-get upgrade -y

              echo "=== [2/5] Installing Docker CLI & Prerequisites on Ubuntu ==="
              apt-get install -y ca-certificates curl gnupg lsb-release unzip awscli

              # Install official Docker CE and Docker CLI
              install -m 0755 -d /etc/apt/keyrings
              curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
              chmod a+r /etc/apt/keyrings/docker.gpg

              echo \
                "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
                $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

              apt-get update -y
              apt-get install -y docker-ce docker-ce-cli containerd.io

              systemctl start docker
              systemctl enable docker
              usermod -aG docker ubuntu

              echo "=== [3/5] Docker CLI Verification ==="
              docker --version

              echo "=== [4/5] Pulling Image from AWS ECR using Docker CLI ==="
              REGION="${var.aws_region}"
              ECR_URL="${var.ecr_repository_url}"
              TAG="${var.image_tag}"

              if [ -n "$ECR_URL" ]; then
                REGISTRY_DOMAIN=$(echo "$ECR_URL" | cut -d'/' -f1)
                echo "Authenticating Docker CLI to ECR: $REGISTRY_DOMAIN in region $REGION..."
                aws ecr get-login-password --region "$REGION" | docker login --username AWS --password-stdin "$REGISTRY_DOMAIN" || true
                
                IMAGE_TO_RUN="$ECR_URL:$TAG"
                echo "Pulling Docker image: $IMAGE_TO_RUN..."
                docker pull "$IMAGE_TO_RUN"
              else
                IMAGE_TO_RUN="${var.docker_image}"
                echo "Running standard image: $IMAGE_TO_RUN..."
                docker pull "$IMAGE_TO_RUN" || true
              fi

              echo "=== [5/5] Running Container on Ports 80 and 3000 ==="
              docker run -d \
                --name agrigantt_live \
                --restart always \
                -p 80:3000 \
                -p 3000:3000 \
                -e NODE_ENV=production \
                -e PORT=3000 \
                "$IMAGE_TO_RUN"

              echo "=== AgriGantt Successfully Deployed on Ubuntu EC2 at $(date) ===" > /var/log/agrigantt_status.txt
              EOF

  root_block_device {
    volume_size           = 20
    volume_type           = "gp3"
    encrypted             = true # DevSecOps standard: EBS encryption at rest
    delete_on_termination = true
  }

  tags = {
    Name = "agrigantt-ubuntu-production-host"
  }
}
