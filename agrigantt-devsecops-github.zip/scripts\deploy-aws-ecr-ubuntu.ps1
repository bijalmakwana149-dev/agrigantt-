# ==============================================================================
# AgriGantt: AWS ECR Docker Push & Ubuntu EC2 Terraform Deployment Script
# ==============================================================================

param(
    [string]$AwsRegion = "us-east-1",
    [string]$AwsAccountId = "",
    [string]$EcrRepoName = "agrigantt-app"
)

Write-Host "=================================================================" -ForegroundColor Green
Write-Host " AgriGantt DevSecOps: AWS ECR Push & Ubuntu EC2 Deployment" -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Green

# 1. Check AWS CLI Authentication
Write-Host "[1/5] Checking AWS CLI Authentication..." -ForegroundColor Cyan
if (-not $AwsAccountId) {
    $AwsAccountId = (aws sts get-caller-identity --query "Account" --output text 2>$null)
}

if (-not $AwsAccountId) {
    Write-Host "ERROR: AWS CLI not configured or not logged in. Run 'aws configure' first." -ForegroundColor Red
    exit 1
}

$EcrRegistry = "$AwsAccountId.dkr.ecr.$AwsRegion.amazonaws.com"
$EcrRepoUrl = "$EcrRegistry/$EcrRepoName"

Write-Host "AWS Account ID: $AwsAccountId" -ForegroundColor Yellow
Write-Host "AWS Region:     $AwsRegion" -ForegroundColor Yellow
Write-Host "ECR Repository: $EcrRepoUrl" -ForegroundColor Yellow

# 2. Ensure ECR Repository Exists
Write-Host "`n[2/5] Creating AWS ECR Repository (if not existing)..." -ForegroundColor Cyan
aws ecr create-repository --repository-name $EcrRepoName --region $AwsRegion 2>$null | Out-Null
Write-Host "ECR repository '$EcrRepoName' verified." -ForegroundColor Green

# 3. Authenticate Docker CLI to AWS ECR
Write-Host "`n[3/5] Authenticating Docker CLI to AWS ECR..." -ForegroundColor Cyan
aws ecr get-login-password --region $AwsRegion | docker login --username AWS --password-stdin $EcrRegistry

# 4. Tag and Push Docker Image via Docker CLI
Write-Host "`n[4/5] Tagging and Pushing Image to AWS ECR via Docker CLI..." -ForegroundColor Cyan
docker tag agrigantt-app:latest "$EcrRepoUrl`:latest"
docker tag agrigantt-app:latest "$EcrRepoUrl`:v1.0.0"
docker push "$EcrRepoUrl`:latest"
Write-Host "Docker image pushed to ECR: $EcrRepoUrl`:latest" -ForegroundColor Green

# 5. Provision Ubuntu EC2 Machine via Terraform
Write-Host "`n[5/5] Provisioning Ubuntu EC2 Instance using Terraform..." -ForegroundColor Cyan
Set-Location terraform
terraform init
terraform apply -auto-approve -var="aws_region=$AwsRegion" -var="ecr_repository_url=$EcrRepoUrl" -var="image_tag=latest"

$PublicIp = (terraform output -raw public_instance_ip 2>$null)

Write-Host "`n=================================================================" -ForegroundColor Green
Write-Host " DEPLOYMENT SUCCESSFUL!" -ForegroundColor Green
Write-Host " Ubuntu EC2 Public Instance IP: $PublicIp" -ForegroundColor Yellow
Write-Host " Live Website (Port 80):        http://$PublicIp" -ForegroundColor Cyan
Write-Host " Live Website (Port 3000):      http://$PublicIp`:3000" -ForegroundColor Cyan
Write-Host " Health Check Endpoint:         http://$PublicIp/api/health" -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Green
Set-Location ..
