#!/bin/bash
# ==============================================================================
# AWS EC2 Cloud-Init User Data Script for AgriGantt DevSecOps Deployment
# ==============================================================================

set -e

# Redirect all stdout & stderr to logfile
exec > >(tee /var/log/user_data.log|logger -t user-data -s 2>/dev/console) 2>&1

echo "=== [1/4] Updating OS Packages ==="
dnf update -y

echo "=== [2/4] Installing Docker and Git ==="
dnf install -y docker git
systemctl start docker
systemctl enable docker
usermod -a -G docker ec2-user

echo "=== [3/4] Pulling Hardened AgriGantt Container Image ==="
# Pull the latest verified container image from registry
docker pull yourdockerhub/agrigantt-app:latest || true

echo "=== [4/4] Starting AgriGantt Container on Port 80 ==="
docker run -d \
  --name agrigantt_live \
  --restart always \
  -p 80:3000 \
  -e NODE_ENV=production \
  -e PORT=3000 \
  yourdockerhub/agrigantt-app:latest

echo "=== Deployment Completed Successfully at $(date) ==="
