@echo off
echo =======================================================
echo  Starting Jenkins CI/CD Container on Docker Desktop...
echo =======================================================

docker volume create jenkins_home >nul 2>&1
docker rm -f jenkins_server >nul 2>&1

docker run -d ^
  --name jenkins_server ^
  --restart unless-stopped ^
  -p 8080:8080 ^
  -p 50000:50000 ^
  -v jenkins_home:/var/jenkins_home ^
  -v //var/run/docker.sock:/var/run/docker.sock ^
  jenkins/jenkins:lts

echo Waiting 20 seconds for Jenkins initialization...
timeout /t 20 /nobreak >nul

echo -------------------------------------------------------
echo  Jenkins Web UI: http://localhost:8080
echo  Initial Admin Password:
docker exec jenkins_server cat /var/jenkins_home/secrets/initialAdminPassword
echo -------------------------------------------------------
pause
