/**
 * AgriGantt - Interactive Gantt Chart Engine
 * Dynamically computes days, progress, dependencies and renders SVG/HTML timeline
 */

class GanttEngine {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.tasks = [];
    this.currentFilter = 'all';
    this.projectStart = new Date("2026-10-01T00:00:00");
    this.projectEnd = new Date("2026-10-31T23:59:59");
    this.totalDays = Math.ceil((this.projectEnd - this.projectStart) / (1000 * 60 * 60 * 24)) + 1;
  }

  setTasks(taskList) {
    this.tasks = taskList;
    this.render();
  }

  filterByPhase(phase) {
    this.currentFilter = phase;
    this.render();
  }

  render() {
    if (!this.container) return;

    const filtered = this.currentFilter === 'all' 
      ? this.tasks 
      : this.tasks.filter(t => t.phase.toLowerCase().includes(this.currentFilter.toLowerCase()));

    if (filtered.length === 0) {
      this.container.innerHTML = `
        <div class="text-center py-5 text-muted">
          <i class="bi bi-inbox fs-1"></i>
          <p class="mt-2">No work packages found matching this filter.</p>
        </div>
      `;
      return;
    }

    let html = `
      <div class="gantt-table">
        <!-- Gantt Header -->
        <div class="gantt-row bg-light fw-bold fs-12 text-muted border-bottom py-2">
          <div class="gantt-task-meta d-flex justify-content-between align-items-center">
            <span>Work Package & Assignee</span>
            <span>Progress</span>
          </div>
          <div class="gantt-timeline-area d-flex align-items-center">
            ${this.renderTimelineHeader()}
          </div>
        </div>

        <!-- Gantt Rows -->
        <div class="gantt-rows-wrapper">
          ${filtered.map(task => this.renderTaskRow(task)).join('')}
        </div>
      </div>
    `;

    this.container.innerHTML = html;
  }

  renderTimelineHeader() {
    let headerHtml = `<div class="w-100 d-flex text-center fs-11">`;
    // Generate weekly markers across the 31 days of October
    const weeks = [
      { label: "W1: Oct 01 - 07", days: 7 },
      { label: "W2: Oct 08 - 14", days: 7 },
      { label: "W3: Oct 15 - 21", days: 7 },
      { label: "W4: Oct 22 - 28", days: 7 },
      { label: "W5: Oct 29 - 31", days: 3 }
    ];

    weeks.forEach(w => {
      const pct = (w.days / this.totalDays) * 100;
      headerHtml += `<div style="width: ${pct}%; border-right: 1px solid #e5e7eb;" class="py-1 px-1 bg-white text-dark-green fw-semibold">${w.label}</div>`;
    });

    headerHtml += `</div>`;
    return headerHtml;
  }

  renderTaskRow(task) {
    const start = new Date(task.startDate + "T00:00:00");
    const end = new Date(task.endDate + "T23:59:59");

    const offsetDays = Math.max(0, (start - this.projectStart) / (1000 * 60 * 60 * 24));
    const durationDays = Math.max(1, (end - start) / (1000 * 60 * 60 * 24) + 1);

    const leftPct = Math.min(100, Math.max(0, (offsetDays / this.totalDays) * 100));
    const widthPct = Math.min(100 - leftPct, Math.max(2.5, (durationDays / this.totalDays) * 100));

    let barColor = 'bg-primary';
    if (task.status === 'Completed') barColor = 'bg-success';
    else if (task.status === 'Planned') barColor = 'bg-warning text-dark';

    const priorityBadge = task.priority === 'Critical' 
      ? '<span class="badge bg-danger fs-11">Critical</span>' 
      : task.priority === 'High' 
        ? '<span class="badge bg-warning text-dark fs-11">High</span>' 
        : '<span class="badge bg-secondary fs-11">Normal</span>';

    return `
      <div class="gantt-row" id="row-${task.id}">
        <!-- Meta Details -->
        <div class="gantt-task-meta d-flex justify-content-between align-items-center">
          <div style="max-width: 200px;">
            <div class="d-flex align-items-center gap-1">
              <span class="badge bg-dark fs-11">${task.id}</span>
              ${priorityBadge}
            </div>
            <div class="fw-semibold fs-12 text-truncate mt-1 text-dark" title="${task.name}">
              ${task.name}
            </div>
            <div class="fs-11 text-muted text-truncate">
              <i class="bi bi-person"></i> ${task.assignee} &bull; <span class="text-primary">${task.iotTarget}</span>
            </div>
          </div>
          <div class="text-end">
            <span class="fw-bold fs-12 ${task.progress === 100 ? 'text-success' : 'text-primary'}">${task.progress}%</span>
            <div class="progress" style="height: 5px; width: 45px;">
              <div class="progress-bar ${barColor}" style="width: ${task.progress}%"></div>
            </div>
          </div>
        </div>

        <!-- Timeline Graphic Bar -->
        <div class="gantt-timeline-area">
          <!-- Background Grid lines -->
          <div class="timeline-grid">
            <div class="timeline-col"></div>
            <div class="timeline-col"></div>
            <div class="timeline-col"></div>
            <div class="timeline-col"></div>
            <div class="timeline-col"></div>
          </div>

          ${task.isMilestone ? `
            <!-- Milestone Diamond Marker -->
            <div class="gantt-milestone-marker" 
                 style="left: calc(${leftPct}% - 10px);" 
                 onclick="inspectTask('${task.id}')"
                 title="[MILESTONE] ${task.name} (${task.startDate})">
            </div>
          ` : `
            <!-- Gantt Duration Bar -->
            <div class="gantt-bar-item ${barColor}" 
                 style="left: ${leftPct}%; width: ${widthPct}%;" 
                 onclick="inspectTask('${task.id}')"
                 title="${task.name} | ${task.startDate} to ${task.endDate} (${task.progress}%)">
              <div class="gantt-bar-progress" style="width: ${task.progress}%;"></div>
              <span class="position-relative z-1 text-truncate">${task.name}</span>
            </div>
          `}
        </div>
      </div>
    `;
  }
}

// Global instance
window.ganttEngine = new GanttEngine('ganttChartContainer');
