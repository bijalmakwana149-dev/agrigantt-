# ==============================================================================
# Terraform Outputs (Public IP & Application Ports)
# ==============================================================================

output "public_instance_ip" {
  description = "Public IPv4 address of the provisioned Ubuntu EC2 instance"
  value       = aws_instance.agrigantt_ec2.public_ip
}

output "application_url_port_80" {
  description = "Direct web URL to access the running application on standard port 80"
  value       = "http://${aws_instance.agrigantt_ec2.public_ip}"
}

output "application_url_port_3000" {
  description = "Direct web URL to access the running application on direct application port 3000"
  value       = "http://${aws_instance.agrigantt_ec2.public_ip}:3000"
}

output "health_check_url" {
  description = "Direct URL for the automated DevSecOps health monitoring probe"
  value       = "http://${aws_instance.agrigantt_ec2.public_ip}/api/health"
}

output "ssh_connection_command" {
  description = "SSH command to connect to the Ubuntu EC2 machine"
  value       = "ssh -i your-key.pem ubuntu@${aws_instance.agrigantt_ec2.public_ip}"
}

output "docker_cli_check_command" {
  description = "Docker CLI command to verify the running container on the Ubuntu EC2 instance"
  value       = "ssh -i your-key.pem ubuntu@${aws_instance.agrigantt_ec2.public_ip} 'docker ps && docker logs agrigantt_live'"
}
