#!/bin/bash
# ==============================================================================
# AgriGantt: AWS ECR Docker Push & Ubuntu EC2 Terraform Deployment Script
# ==============================================================================

set -e

AWS_REGION="${1:-us-east-1}"
ECR_REPO_NAME="agrigantt-app"

echo "================================================================="
echo " AgriGantt DevSecOps: AWS ECR Push & Ubuntu EC2 Deployment"
echo "================================================================="

# 1. Fetch AWS Account ID
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
ECR_REPO_URL="${ECR_REGISTRY}/${ECR_REPO_NAME}"

echo "AWS Account ID: ${AWS_ACCOUNT_ID}"
echo "AWS Region:     ${AWS_REGION}"
echo "ECR Repository: ${ECR_REPO_URL}"

# 2. Create ECR Repository if it doesn't exist
echo -e "\n[1/4] Ensuring AWS ECR repository exists..."
aws ecr create-repository --repository-name "${ECR_REPO_NAME}" --region "${AWS_REGION}" 2>/dev/null || true

# 3. Authenticate Docker CLI to ECR
echo -e "\n[2/4] Authenticating Docker CLI to AWS ECR..."
aws ecr get-login-password --region "${AWS_REGION}" | docker login --username AWS --password-stdin "${ECR_REGISTRY}"

# 4. Tag and Push Image using Docker CLI
echo -e "\n[3/4] Tagging and pushing Docker image to ECR..."
docker tag agrigantt-app:latest "${ECR_REPO_URL}:latest"
docker tag agrigantt-app:latest "${ECR_REPO_URL}:v1.0.0"
docker push "${ECR_REPO_URL}:latest"

# 5. Provision Ubuntu EC2 Machine via Terraform
echo -e "\n[4/4] Provisioning Ubuntu EC2 Machine with Terraform..."
cd terraform
terraform init
terraform apply -auto-approve \
  -var="aws_region=${AWS_REGION}" \
  -var="ecr_repository_url=${ECR_REPO_URL}" \
  -var="image_tag=latest"

PUBLIC_IP=$(terraform output -raw public_instance_ip)

echo "================================================================="
echo " DEPLOYMENT SUCCESSFUL!"
echo " Ubuntu EC2 Public Instance IP: ${PUBLIC_IP}"
echo " Live Website (Port 80):        http://${PUBLIC_IP}"
echo " Live Website (Port 3000):      http://${PUBLIC_IP}:3000"
echo " Health Check Endpoint:         http://${PUBLIC_IP}/api/health"
echo "================================================================="
