# JIRA Project Management Backlog & Sprint Execution Plan

**Project:** AgriGantt - IoT Smart Agriculture Collaborative DevSecOps Platform  
**Project Key:** `AGRI`  
**Methodology:** Agile Scrum / Kanban  
**Course:** DevSecOps Lab – CIAP Microproject  

---

## 1. JIRA Epics Overview

| Epic Key | Epic Name | Summary & Scope | Story Points |
| :--- | :--- | :--- | :--- |
| **AGRI-EPIC-1** | **IoT Agriculture Architecture** | Define LoRaWAN mesh, soil telemetry nodes, optical NPK sensors, and precision drip irrigation specifications. | 13 SP |
| **AGRI-EPIC-2** | **Collaborative Gantt Web Platform** | Develop responsive web application with SVG/HTML Gantt chart, multi-role switcher, and RESTful telemetry API. | 21 SP |
| **AGRI-EPIC-3** | **Containerization & Hardening** | Author multi-stage non-root Dockerfile, configure docker-compose, and minimize base image attack surface. | 8 SP |
| **AGRI-EPIC-4** | **DevSecOps Security Scanning** | Integrate SonarQube SAST and Trivy vulnerability scanner to enforce automated quality gates. | 13 SP |
| **AGRI-EPIC-5** | **AWS Cloud IaC & Jenkins Pipeline** | Provision AWS VPC/EC2 using Terraform and automate end-to-end building, scanning, and deployment via Jenkins. | 21 SP |

**Total Estimated Backlog:** 76 Story Points

---

## 2. Sprint Execution Plan

### Sprint 1: Foundation, Application Architecture & Gantt Engine (Weeks 1–2)
* **Goal:** Establish Git repository, build the interactive Gantt chart web UI, create REST APIs, and implement unit tests.
* **Stories:**
  - `AGRI-101` [5 SP]: Setup Git repository, branch strategy (`main`, `dev`, `feature/*`), and ESLint configurations.
  - `AGRI-102` [8 SP]: Develop interactive Gantt chart engine (timeline rendering, milestone diamonds, progress computation).
  - `AGRI-103` [5 SP]: Implement Express REST API endpoints (`/api/tasks`, `/api/iot-nodes`, `/api/health`).
  - `AGRI-104` [3 SP]: Write unit and integration test suite using Node.js native test runner.

### Sprint 2: Containerization & DevSecOps Security Scanning (Weeks 2–3)
* **Goal:** Containerize application using hardened Docker practices and integrate SonarQube SAST and Trivy scanning.
* **Stories:**
  - `AGRI-201` [5 SP]: Write multi-stage Dockerfile targeting `node:20-alpine` with non-root user `nodejs` (UID 1001).
  - `AGRI-202` [5 SP]: Configure SonarQube scanner properties (`sonar-project.properties`) and define Quality Gate rules.
  - `AGRI-203` [5 SP]: Configure Trivy vulnerability scans for filesystem dependencies and Docker images; block on Critical CVEs.
  - `AGRI-204` [3 SP]: Compile Basic Vulnerability Report detailing CVE findings, threat vectors, and mitigations.

### Sprint 3: AWS Terraform Infrastructure & Jenkins CI/CD Automation (Weeks 3–4)
* **Goal:** Provision AWS infrastructure with Terraform, automate CI/CD pipeline in Jenkins, and conduct live deployment.
* **Stories:**
  - `AGRI-301` [8 SP]: Write modular Terraform configuration for AWS VPC, Public Subnet, Security Group, and EC2 instance.
  - `AGRI-302` [5 SP]: Enforce Least Privilege on AWS Security Group (restrict SSH port 22 to administrator CIDR).
  - `AGRI-303` [8 SP]: Build Declarative Jenkinsfile containing all 10 stages (SCM, Lint, Test, SonarQube, Docker, Trivy, Terraform, Deploy).
  - `AGRI-304` [3 SP]: Execute end-to-end deployment verification and record demonstration video.

---

## 3. Detailed User Stories & Acceptance Criteria

### Story AGRI-201: Hardened Containerization
* **As a:** DevSecOps Engineer  
* **I want to:** Containerize the AgriGantt application using a multi-stage non-root Alpine base image  
* **So that:** The container cannot compromise the host environment or run with elevated root privileges.  
* **Acceptance Criteria:**
  1. `docker build` completes without warning or error.
  2. The image uses `USER nodejs` (UID 1001) instead of root.
  3. `HEALTHCHECK` directive is configured to query `/api/health` every 30 seconds.
  4. Total image size is under 180MB.

### Story AGRI-303: Declarative Jenkins CI/CD Pipeline
* **As a:** DevOps / QA Engineer  
* **I want to:** Automate testing, security scanning, and deployment through a 10-stage Jenkins pipeline  
* **So that:** Every code commit is verified for zero Critical CVEs before touching AWS production infrastructure.  
* **Acceptance Criteria:**
  1. Pipeline triggers automatically on code push.
  2. SonarQube Quality Gate blocks pipeline if rating drops below 'A'.
  3. Trivy scan fails pipeline if any CRITICAL vulnerability is present.
  4. Terraform provisions or updates AWS resources with automated state validation.
  5. Automated curl probe to `/api/health` returns HTTP 200 OK.
