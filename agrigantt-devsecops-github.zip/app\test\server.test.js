/**
 * Unit & Integration Tests for AgriGantt Server API
 * Built using Node.js native test runner and assert
 */

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const { app } = require('../server');

// Helper to make local HTTP requests
function request(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: body ? JSON.parse(body) : null
          });
        } catch (e) {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: body
          });
        }
      });
    });

    req.on('error', reject);
    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

describe('AgriGantt DevSecOps API Test Suite', () => {
  let server;
  let PORT;

  before(async () => {
    await new Promise((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        PORT = server.address().port;
        resolve();
      });
    });
  });

  after(async () => {
    if (server) {
      await new Promise(resolve => server.close(resolve));
    }
  });

  it('1. Health Check Endpoint should return HTTP 200 and healthy status', async () => {
    const res = await request({
      hostname: '127.0.0.1',
      port: PORT,
      path: '/api/health',
      method: 'GET'
    });

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.status, 'healthy');
    assert.ok(res.body.uptime >= 0);
  });

  it('2. GET /api/tasks should return list of IoT Smart Agriculture work packages', async () => {
    const res = await request({
      hostname: '127.0.0.1',
      port: PORT,
      path: '/api/tasks',
      method: 'GET'
    });

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(Array.isArray(res.body.data));
    assert.ok(res.body.data.length > 0);
  });

  it('3. GET /api/iot-nodes should return live telemetry of deployed field sensors', async () => {
    const res = await request({
      hostname: '127.0.0.1',
      port: PORT,
      path: '/api/iot-nodes',
      method: 'GET'
    });

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.count >= 4);
    assert.ok(res.body.data.some(n => n.type.includes('Soil Moisture')));
  });

  it('4. GET /api/security/audit should reflect SonarQube & Trivy compliance', async () => {
    const res = await request({
      hostname: '127.0.0.1',
      port: PORT,
      path: '/api/security/audit',
      method: 'GET'
    });

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.data.sonarQube.status, 'PASSED');
    assert.strictEqual(res.body.data.trivyScan.critical, 0);
    assert.strictEqual(res.body.data.sonarQube.vulnerabilities, 0);
    assert.ok(res.body.data.sdgAlignment.includes('SDG 9'));
  });

  it('5. POST /api/tasks validation should reject incomplete task payloads with HTTP 400', async () => {
    const res = await request({
      hostname: '127.0.0.1',
      port: PORT,
      path: '/api/tasks',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, { name: '' });

    assert.strictEqual(res.statusCode, 400);
    assert.strictEqual(res.body.success, false);
  });
});
