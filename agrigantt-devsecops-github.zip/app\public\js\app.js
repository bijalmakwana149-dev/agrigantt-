/**
 * AgriGantt - Application State & Collaboration Logic
 */

let activeUser = {
  name: "Marcus Vance",
  role: "DevSecOps Engineer"
};

let currentTasks = [];

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Role Switcher
  const roleSelect = document.getElementById('userRoleSelect');
  if (roleSelect) {
    roleSelect.addEventListener('change', (e) => {
      const [name, role] = e.target.value.split('|');
      activeUser.name = name;
      activeUser.role = role;
      showNotification(`Switched active collaborator to ${name} (${role})`, 'info');
    });
  }

  // Load Initial Data
  fetchTasks();
  fetchTelemetry();
  fetchActivities();

  // Periodic Telemetry Simulator (every 10 seconds)
  setInterval(() => {
    fetchTelemetry();
  }, 10000);
});

// Fetch tasks and render Gantt
async function fetchTasks() {
  try {
    const res = await fetch('/api/tasks');
    const json = await res.json();
    if (json.success) {
      currentTasks = json.data;
      window.ganttEngine.setTasks(currentTasks);
      updateDashboardMetrics(currentTasks);
    }
  } catch (err) {
    console.error('Failed to load tasks:', err);
  }
}

// Update Top Dashboard Metrics
function updateDashboardMetrics(tasks) {
  const totalTasksEl = document.getElementById('totalTasksCount');
  const milestonesEl = document.getElementById('milestonesCount');
  const overallProgressEl = document.getElementById('overallProgress');

  if (totalTasksEl) totalTasksEl.textContent = `${tasks.length} Packages`;
  
  const milestones = tasks.filter(t => t.isMilestone);
  if (milestonesEl) milestonesEl.textContent = `${milestones.length} Milestones`;

  const totalProgress = tasks.reduce((acc, t) => acc + (t.progress || 0), 0);
  const avg = tasks.length > 0 ? (totalProgress / tasks.length).toFixed(1) : 0;
  if (overallProgressEl) overallProgressEl.textContent = `${avg}%`;
}

// Phase Filter
function filterPhase(phase) {
  const buttons = document.querySelectorAll('.card-header .btn-group button');
  buttons.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');

  window.ganttEngine.filterByPhase(phase);
}

// Handle New Task Submission
async function handleCreateTask(e) {
  e.preventDefault();
  const name = document.getElementById('taskName').value;
  const phase = document.getElementById('taskPhase').value;
  const target = document.getElementById('taskTarget').value;
  const start = document.getElementById('taskStart').value;
  const end = document.getElementById('taskEnd').value;
  const priority = document.getElementById('taskPriority').value;
  const status = document.getElementById('taskStatus').value;
  const progress = parseInt(document.getElementById('taskProgress').value) || 0;
  const isMilestone = document.getElementById('taskIsMilestone').checked;

  const payload = {
    name,
    phase,
    startDate: start,
    endDate: end,
    priority,
    status,
    progress,
    isMilestone,
    iotTarget: target,
    assignee: activeUser.name,
    role: activeUser.role
  };

  try {
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      // Close modal
      const modalEl = document.getElementById('addTaskModal');
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
      document.getElementById('addTaskForm').reset();

      fetchTasks();
      fetchActivities();
      showNotification(`Work package "${name}" added successfully!`, 'success');
    }
  } catch (err) {
    alert('Error creating task: ' + err.message);
  }
}

// Inspect & Quick Edit Task
function inspectTask(taskId) {
  const task = currentTasks.find(t => t.id === taskId);
  if (!task) return;

  const newProgress = prompt(`[${task.id}] ${task.name}\nAssignee: ${task.assignee} (${task.role})\nIoT Target: ${task.iotTarget}\nStatus: ${task.status}\n\nEnter updated completion progress (0-100%):`, task.progress);
  if (newProgress !== null && !isNaN(newProgress)) {
    const progressVal = Math.min(100, Math.max(0, parseInt(newProgress)));
    let newStatus = task.status;
    if (progressVal === 100) newStatus = 'Completed';
    else if (progressVal > 0) newStatus = 'In Progress';
    else newStatus = 'Planned';

    fetch(`/api/tasks/${taskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        progress: progressVal,
        status: newStatus,
        updatedBy: activeUser.name,
        role: activeUser.role
      })
    }).then(() => {
      fetchTasks();
      fetchActivities();
      showNotification(`Task ${taskId} progress updated to ${progressVal}%`, 'success');
    });
  }
}

// Fetch IoT Field Telemetry
async function fetchTelemetry() {
  const container = document.getElementById('iotNodesList');
  if (!container) return;

  try {
    const res = await fetch('/api/iot-nodes');
    const json = await res.json();
    if (json.success) {
      container.innerHTML = json.data.map(node => `
        <div class="iot-node-card d-flex justify-content-between align-items-center">
          <div>
            <div class="fw-bold fs-12 text-dark">
              <i class="bi bi-cpu text-primary me-1"></i>${node.id} &bull; <span class="text-muted fw-normal">${node.sector}</span>
            </div>
            <div class="fs-11 text-muted">${node.type}</div>
            <div class="fs-11 text-success fw-semibold"><i class="bi bi-activity"></i> ${node.value} | ${node.temp}</div>
          </div>
          <div class="text-end">
            <span class="badge ${node.status.includes('Low') ? 'bg-warning text-dark' : 'bg-success'} fs-11">${node.status}</span>
            <div class="fs-11 text-muted mt-1"><i class="bi bi-battery-charging text-primary"></i> ${node.battery}</div>
          </div>
        </div>
      `).join('');
    }
  } catch (err) {
    console.error('Error fetching telemetry:', err);
  }
}

// Fetch Activity Feed
async function fetchActivities() {
  const feed = document.getElementById('activityFeedList');
  const countBadge = document.getElementById('activityCountBadge');
  if (!feed) return;

  try {
    const res = await fetch('/api/collaborate/activities');
    const json = await res.json();
    if (json.success) {
      if (countBadge) countBadge.textContent = `${json.data.length} Events`;
      feed.innerHTML = json.data.map(act => `
        <div class="activity-item">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <span class="fw-bold text-dark fs-12">${act.user}</span>
            <span class="badge bg-secondary-subtle text-secondary fs-10">${act.badge || 'Update'}</span>
          </div>
          <div class="text-muted fs-11">${act.action}</div>
          <div class="text-light-opacity text-secondary fs-10 mt-1">${act.timestamp}</div>
        </div>
      `).join('');
    }
  } catch (err) {
    console.error('Error loading activities:', err);
  }
}

// Post Collaborative Comment
async function postCollaborationComment(e) {
  e.preventDefault();
  const input = document.getElementById('commentInput');
  const comment = input.value.trim();
  if (!comment) return;

  try {
    const res = await fetch('/api/collaborate/comment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user: activeUser.name,
        role: activeUser.role,
        comment: comment,
        badge: "Comment"
      })
    });
    const json = await res.json();
    if (json.success) {
      input.value = '';
      fetchActivities();
      showNotification('Note shared with collaborative team!', 'success');
    }
  } catch (err) {
    alert('Error posting comment: ' + err.message);
  }
}

// Visual Toast Notification
function showNotification(msg, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `position-fixed bottom-0 end-0 m-3 alert alert-${type} shadow-lg py-2 px-3 fs-13 z-3`;
  toast.style.zIndex = "9999";
  toast.innerHTML = `<i class="bi bi-info-circle-fill me-2"></i> ${msg}`;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 3500);
}
