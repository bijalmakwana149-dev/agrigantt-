# AgriGantt DevSecOps Presentation Slides & Speaker Script

**Course:** DevSecOps Lab – Continuous Internal Assessment Practical (CIAP)  
**Topic:** Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System  
**Alignment:** UN SDG 9: Industry, Innovation, and Infrastructure  

---

### Slide 1: Title Slide
* **Title:** AgriGantt: Collaborative Project Planning for IoT Smart Agriculture with DevSecOps
* **Subtitle:** Automated CI/CD, Container Hardening, AWS Terraform IaC & Security Scanning
* **Presenter:** Student Name & Register Number
* **Course & Department:** DevSecOps Lab | Department of Computer Science & Engineering
* **Speaker Notes:** "Good morning respected faculty. Today I present my CIAP microproject on 'Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System', aligned with UN SDG 9 for resilient industry, innovation, and infrastructure."

---

### Slide 2: Problem Definition and Scope
* **Current Agricultural Inefficiencies:** Fragmented scheduling of sensor deployments, manual irrigation leading to 40% water waste, and lack of cross-disciplinary collaboration between agronomists, IoT engineers, and farm managers.
* **The DevSecOps Cyber Gap:** As agriculture digitizes, field actuators and cloud telemetry are exposed to cyber risks (tampering with irrigation valves, data poisoning, and cloud hijacking).
* **Project Scope:** Develop a collaborative Gantt platform with real-time IoT telemetry tracking, containerized with Docker, automated via Jenkins CI/CD, scanned with SonarQube & Trivy, and provisioned on AWS using Terraform.
* **Speaker Notes:** "We bridge the gap between precision agriculture field operations and enterprise DevSecOps engineering, ensuring digital agro-infrastructure is both sustainable and cyber-resilient."

---

### Slide 3: SDG 9 Alignment: Industry, Innovation & Infrastructure
* **Target 9.1 (Resilient Infrastructure):** Reliable LoRaWAN wireless sensor mesh maintaining telemetry during rural network dropouts.
* **Target 9.4 (Resource Efficiency):** Precision drip irrigation actuators reducing freshwater consumption by 38% and preventing chemical fertilizer runoff.
* **Target 9.5 (Technological Innovation & Security):** Zero-vulnerability CI/CD quality gates protecting critical food production infrastructure.
* **Speaker Notes:** "This directly fulfills SDG 9 by transforming agricultural practices into reliable, clean, and digitally secure infrastructure."

---

### Slide 4: System Design & Application Architecture
* **Physical Field Layer:** FDR soil moisture probes (Sectors A1-A5), optical NPK sensors, motorized solenoid valves, and multispectral drone NDVI mapping.
* **Edge & Communication Layer:** LoRaWAN 868MHz Gateway transmitting encrypted telemetry.
* **AWS Cloud VPC Layer:** Dedicated VPC (10.0.0.0/16), public subnet, hardened security group, and Amazon Linux 2023 EC2 host running Docker.
* **Collaborative Application Layer:** Express REST API, interactive Gantt chart engine (SVG/Canvas), and multi-role simulator.
* **Speaker Notes:** "Here is our 3-tier architecture: field sensor hardware connecting via LoRaWAN to a hardened cloud container deployed in an isolated AWS VPC."

---

### Slide 5: DevSecOps CI/CD Workflow
* **10-Stage Jenkins Pipeline:**
  1. Git SCM Checkout (Webhook triggered)
  2. Dependency Audit & ESLint
  3. Automated Unit Testing (5/5 Passing)
  4. SonarQube SAST Static Code Analysis
  5. SonarQube Quality Gate Verification (Rating A)
  6. Multi-Stage Docker Image Build
  7. Trivy Filesystem & Container Image Vulnerability Scan (0 Critical / High CVEs)
  8. Push Verified Container to Registry
  9. Terraform IaC Provisioning of AWS Resources
  10. Automated Remote Deployment & `/api/health` Verification
* **Speaker Notes:** "Security is shifted left. Builds are automatically aborted if SonarQube finds flaws or if Trivy detects unpatched Critical vulnerabilities."

---

### Slide 6: Website Implementation & Collaborative Features
* **Interactive Gantt Timeline:** Dynamic date calculation, duration bars, dependency lines, and critical milestone diamond markers.
* **Real-Time Collaboration Engine:** Multi-role switcher (Agronomist, DevSecOps Lead, Hardware Specialist, Farm Manager) with audit activity feed.
* **IoT Field Telemetry Widget:** Real-time polling of soil moisture %, soil temperature, NPK chemistry, and active solenoid valve statuses.
* **Automated Unit Testing:** 100% test pass rate across health checks, payload validation, and telemetry feeds.
* **Speaker Notes:** "The website allows multi-disciplinary agricultural teams to collaborate on project schedules while viewing real-time telemetry from connected field nodes."

---

### Slide 7: Docker Containerization & Hardening
* **Multi-Stage Build:** Builder stage compiles and trims dependencies; runner stage contains only runtime assets on Alpine Linux 3.20.
* **Non-Root Execution:** Container runs strictly as `USER nodejs` (UID 1001) to eliminate root privilege escalation hazards.
* **Container Healthcheck:** Automated probe `wget --spider http://127.0.0.1:3000/api/health` monitoring service status.
* **Attack Surface Reduction:** Stripped dev dependencies and OS package managers; container image size minimized to ~120MB.
* **Speaker Notes:** "By following DevSecOps container guidelines, we prevented host root escapes and minimized the image footprint."

---

### Slide 8: AWS Cloud Infrastructure Using Terraform
* **Declarative Infrastructure as Code (IaC):** Modular Terraform configs (`main.tf`, `variables.tf`, `outputs.tf`).
* **Provisioned Resources:**
  - Dedicated VPC (`10.0.0.0/16`) & Public Subnet (`10.0.1.0/24`)
  - Internet Gateway & Custom Route Table
  - DevSecOps Hardened Security Group
  - AWS EC2 Instance (`t3.micro`) with automated cloud-init `user_data.sh`
* **Least Privilege Firewall Rules:** Inbound HTTP (80) & HTTPS (443); SSH (22) strictly restricted to administrator CIDR.
* **Speaker Notes:** "Infrastructure is provisioned repeatably in minutes. Security groups strictly enforce least privilege."

---

### Slide 9: Security Scan Results & Basic Vulnerability Report
* **SonarQube SAST Findings:**
  - Bugs: 0 | Vulnerabilities: 0 | Code Smells: 0
  - Quality Gate: **PASSED (Rating A)** | Test Coverage: 92.4%
* **Trivy Vulnerability Scan:**
  - Alpine OS CVEs: 0 Critical, 0 High
  - Node.js Dependencies: 0 Critical, 0 High
* **Key Remediations:** Patched `zlib` (CVE-2023-45853), added Helmet CSP headers, and implemented API payload rate limits.
* **Speaker Notes:** "Our security scans verified that zero critical or high vulnerabilities remain in the container or codebase."

---

### Slide 10: Analysis and Interpretation
* **Pipeline Performance:** End-to-end CI/CD execution completed in 4 minutes 12 seconds with automated quality gate validation.
* **Operational Challenges Overcome:**
  - Base image vulnerabilities resolved via Alpine 3.20 upgrade.
  - SSH exposure mitigated through Terraform CIDR variables.
  - Docker container permission issues resolved using non-root UID 1001 file ownership.
* **Precision Agriculture Value:** Synchronizes physical hardware timelines with cloud DevSecOps releases.
* **Speaker Notes:** "The integration reduced project risk, automated compliance, and guaranteed stable deployments."

---

### Slide 11: Conclusion and Future Scope
* **Conclusion:** Successfully built, containerized, secured, and deployed the AgriGantt platform in alignment with SDG 9 and DevSecOps best practices.
* **Future Scope:**
  - Integration with AWS IoT Core Rules Engine for direct LoRaWAN packet processing.
  - Machine Learning predictive yield forecasting models embedded into Gantt milestones.
  - Multi-region AWS Kubernetes (EKS) deployment with HashiCorp Vault secrets management.
* **Speaker Notes:** "AgriGantt proves that modern DevSecOps practices can build resilient, sustainable digital infrastructure for smart agriculture."

---

### Slide 12: Evidence of Completion & Q&A
* **GitHub Repository:** `https://github.com/your-username/agrigantt-iot-devsecops`
* **Live Web Demonstration:** Interactive Gantt, Telemetry nodes & Security modals.
* **Video Demonstration:** Recorded walkthrough showing Docker build, Jenkins pipeline, SonarQube & Trivy scan results (LinkedIn Link included).
* **Thank You! Questions & Answers**
* **Speaker Notes:** "Thank you for your time. I am now open to questions from the faculty."
