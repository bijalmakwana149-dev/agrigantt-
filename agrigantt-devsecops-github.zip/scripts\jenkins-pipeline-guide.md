# Jenkins CI/CD Pipeline Setup Guide for AgriGantt

Follow these simple steps to run your project build in **Jenkins** on **Docker Desktop**.

---

## Step 1: Launch Jenkins via Docker

Open PowerShell and run:
```powershell
cd C:\Users\User\.gemini\antigravity\scratch\gantt-iot-smart-agri-devsecops
.\scripts\start-jenkins.ps1
```
*Or double click:* `scripts\start-jenkins.bat`

This starts Jenkins on port `8080` with the Docker socket mounted so Jenkins can execute `docker build`.

---

## Step 2: Unlock Jenkins

1. Open your browser and go to: **`http://localhost:8080`**
2. When prompted for the **Administrator password**, copy the password printed by the script, or run:
   ```powershell
   docker exec jenkins_server cat /var/jenkins_home/secrets/initialAdminPassword
   ```
3. Paste the password and click **Continue**.
4. Click **"Install suggested plugins"** (takes ~1 minute).
5. Click **"Continue as admin"** and **"Save and Finish"**.

---

## Step 3: Create the Pipeline Project

1. On the Jenkins dashboard, click **"New Item"** (top left).
2. Enter the item name: **`AgriGantt-DevSecOps-Pipeline`**.
3. Select **"Pipeline"** as the project type and click **OK**.

---

## Step 4: Configure the Pipeline Script

1. Scroll down to the **Pipeline** section at the bottom.
2. Under **Definition**, ensure **"Pipeline script"** is selected.
3. Open [`jenkins/Jenkinsfile`](../jenkins/Jenkinsfile) from your project folder, copy its contents, and paste it into the script text box.
4. Click **Save**.

---

## Step 5: Run the Build

1. On the left sidebar, click **"Build Now"**.
2. Click on the build number (e.g., **#1**) under **Build History**.
3. Click **"Console Output"** to watch the real-time execution of the 10 stages:
   - SCM Checkout
   - Dependency Audit & Lint
   - Automated Unit Testing (5/5 Passing)
   - SonarQube SAST Analysis & Quality Gate
   - Docker Multi-Stage Image Build
   - Trivy Security Vulnerability Scan
   - Registry Tagging
   - Terraform AWS IaC Validation
   - Remote Deployment & `/api/health` probe
4. All stages will show green checkmarks indicating success!
