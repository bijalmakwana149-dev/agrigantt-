#!/usr/bin/env python3
"""
Python script to generate professional AgriGantt DevSecOps Presentation in .pptx format
Uses python-pptx library
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def build_presentation():
    prs = Presentation()
    # Set 16:9 widescreen format
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Theme Colors
    COLOR_PRIMARY = RGBColor(27, 67, 50)       # Dark Green #1B4332
    COLOR_SECONDARY = RGBColor(45, 106, 79)    # Forest Green #2D6A4F
    COLOR_ACCENT = RGBColor(217, 119, 6)       # Amber Orange #D97706
    COLOR_DARK = RGBColor(31, 41, 55)          # Dark Slate
    COLOR_LIGHT = RGBColor(243, 244, 246)      # Off-white
    COLOR_WHITE = RGBColor(255, 255, 255)
    COLOR_MUTED = RGBColor(107, 114, 128)

    blank_layout = prs.slide_layouts[6]

    def add_header(slide, title_text, category_text="DEVSECOPS LAB CIAP MICROPROJECT"):
        # Header background banner
        header_box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(1.2))
        header_box.fill.solid()
        header_box.fill.fore_color.rgb = COLOR_PRIMARY
        header_box.line.color.rgb = COLOR_PRIMARY

        # Category text
        cat_p = header_box.text_frame.paragraphs[0]
        cat_p.text = category_text.upper()
        cat_p.font.size = Pt(11)
        cat_p.font.bold = True
        cat_p.font.color.rgb = COLOR_ACCENT

        # Title text
        title_p = header_box.text_frame.add_paragraph()
        title_p.text = title_text
        title_p.font.size = Pt(22)
        title_p.font.bold = True
        title_p.font.color.rgb = COLOR_WHITE

        # Footer banner
        footer_box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(7.1), Inches(13.333), Inches(0.4))
        footer_box.fill.solid()
        footer_box.fill.fore_color.rgb = COLOR_LIGHT
        footer_box.line.color.rgb = COLOR_LIGHT
        
        fp = footer_box.text_frame.paragraphs[0]
        fp.text = "AgriGantt: Gantt-Based Collaborative Project Plan for IoT Smart Agriculture | Aligned with UN SDG 9"
        fp.font.size = Pt(10)
        fp.font.color.rgb = COLOR_MUTED

    # -------------------------------------------------------------
    # SLIDE 1: Title Slide
    # -------------------------------------------------------------
    s1 = prs.slides.add_slide(blank_layout)
    bg1 = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    bg1.fill.solid()
    bg1.fill.fore_color.rgb = COLOR_PRIMARY
    bg1.line.color.rgb = COLOR_PRIMARY

    # Title Card
    card = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.5), Inches(1.2), Inches(10.333), Inches(5.1))
    card.fill.solid()
    card.fill.fore_color.rgb = COLOR_WHITE
    card.line.color.rgb = COLOR_ACCENT
    card.line.width = Pt(2)

    tf = card.text_frame
    tf.word_wrap = True
    
    p0 = tf.paragraphs[0]
    p0.text = "COURSE: DEVSECOPS LAB (CIAP MICROPROJECT)"
    p0.font.size = Pt(13)
    p0.font.bold = True
    p0.font.color.rgb = COLOR_ACCENT
    p0.alignment = PP_ALIGN.CENTER

    p1 = tf.add_paragraph()
    p1.text = "Gantt-Based Collaborative Project Plan for an\nIoT Smart Agriculture System"
    p1.font.size = Pt(28)
    p1.font.bold = True
    p1.font.color.rgb = COLOR_PRIMARY
    p1.alignment = PP_ALIGN.CENTER

    p2 = tf.add_paragraph()
    p2.text = "End-to-End DevSecOps: Docker Containerization, Jenkins CI/CD, AWS Terraform IaC, SonarQube & Trivy Security"
    p2.font.size = Pt(14)
    p2.font.color.rgb = COLOR_MUTED
    p2.alignment = PP_ALIGN.CENTER

    p3 = tf.add_paragraph()
    p3.text = "\n★ Aligned with UN Sustainable Development Goal 9: Industry, Innovation, and Infrastructure ★"
    p3.font.size = Pt(13)
    p3.font.bold = True
    p3.font.color.rgb = COLOR_SECONDARY
    p3.alignment = PP_ALIGN.CENTER

    p4 = tf.add_paragraph()
    p4.text = "\nPresented by: Student / DevSecOps Engineer | Continuous Internal Assessment Practical"
    p4.font.size = Pt(12)
    p4.font.color.rgb = COLOR_DARK
    p4.alignment = PP_ALIGN.CENTER

    # Helper function for 2-column cards
    def add_card(slide, left, top, width, height, title, items, border_color=COLOR_SECONDARY, fill_color=COLOR_WHITE):
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        box.fill.solid()
        box.fill.fore_color.rgb = fill_color
        box.line.color.rgb = border_color
        box.line.width = Pt(1.5)

        tf = box.text_frame
        tf.word_wrap = True
        
        tp = tf.paragraphs[0]
        tp.text = title
        tp.font.size = Pt(16)
        tp.font.bold = True
        tp.font.color.rgb = COLOR_PRIMARY
        
        for item in items:
            p = tf.add_paragraph()
            p.text = "• " + item
            p.font.size = Pt(12)
            p.font.color.rgb = COLOR_DARK
            p.space_after = Pt(4)
        return box

    # -------------------------------------------------------------
    # SLIDE 2: Problem Definition and Scope (15%)
    # -------------------------------------------------------------
    s2 = prs.slides.add_slide(blank_layout)
    add_header(s2, "Problem Definition & Project Scope")

    add_card(s2, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Agricultural Challenges & Cyber Vulnerabilities",
             [
                 "Fragmented Project Schedules: LoRaWAN gateways, sensors, and drip actuators are deployed ad-hoc without unified dependency tracking.",
                 "Severe Resource Waste: Unmonitored flood irrigation consumes up to 40% excess freshwater and induces chemical fertilizer runoff.",
                 "DevSecOps Void in Precision Ag: Field controllers and telemetry pipelines lack automated security verification, risking cyber tampering.",
                 "Unauthorized Actuator Tampering: Compromised valves can drown crops, deplete water reserves, or halt fertigation cycles."
             ])

    add_card(s2, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "AgriGantt Proposed Scope & Solutions",
             [
                 "Interactive Gantt System: Dynamic milestone scheduling, critical path visualization, and task dependency mapping.",
                 "Multi-Stakeholder Collaboration: Shared workspace for Agronomists, DevSecOps Leads, Hardware Engineers, and Farm Leads.",
                 "Automated 'Shift-Left' DevSecOps: Every commit undergoes SonarQube SAST analysis and Trivy vulnerability gate checking.",
                 "AWS Cloud Infrastructure via Terraform: Provision dedicated VPC and EC2 environments with least-privilege security groups.",
                 "Containerized Reliability: Multi-stage, non-root Dockerized deployment with automated health probing."
             ])

    # -------------------------------------------------------------
    # SLIDE 3: SDG 9 Alignment: Industry, Innovation & Infrastructure
    # -------------------------------------------------------------
    s3 = prs.slides.add_slide(blank_layout)
    add_header(s3, "Alignment with UN Sustainable Development Goal 9 (SDG 9)")

    add_card(s3, Inches(0.8), Inches(1.6), Inches(3.7), Inches(5.0),
             "Target 9.1: Resilient Infrastructure",
             [
                 "Decentralized LoRaWAN 868MHz Mesh topology.",
                 "Battery & solar-backed soil sensor nodes.",
                 "Withstands adverse rural weather without relying on uninterrupted commercial grid power.",
                 "Local buffering ensures zero telemetry loss during regional cellular outages.",
                 "KPI: 99.8% Field Telemetry Availability."
             ], border_color=COLOR_PRIMARY)

    add_card(s3, Inches(4.8), Inches(1.6), Inches(3.7), Inches(5.0),
             "Target 9.4: Clean & Sustainable Tech",
             [
                 "Closed-loop automated precision drip irrigation.",
                 "Optical NPK probes eliminate guesswork in chemical nitrogen-phosphorus fertilization.",
                 "Prevents chemical leaching into groundwater basins.",
                 "Directly conserves scarce freshwater resources.",
                 "KPI: Up to 38% Water Savings & 25% Fertilizer Reduction."
             ], border_color=COLOR_ACCENT)

    add_card(s3, Inches(8.8), Inches(1.6), Inches(3.7), Inches(5.0),
             "Target 9.5: DevSecOps Cyber Resilience",
             [
                 "Rigorous DevSecOps quality gates in CI/CD pipeline.",
                 "SonarQube SAST & Trivy container CVE scans.",
                 "Zero-Trust non-root container deployment on AWS.",
                 "Secures critical national agricultural cyber-physical infrastructure.",
                 "KPI: 0 Critical & 0 High Vulnerabilities in production."
             ], border_color=COLOR_SECONDARY)

    # -------------------------------------------------------------
    # SLIDE 4: System Design & Application Architecture
    # -------------------------------------------------------------
    s4 = prs.slides.add_slide(blank_layout)
    add_header(s4, "System Design & Multi-Tier Architecture")

    add_card(s4, Inches(0.8), Inches(1.6), Inches(3.7), Inches(5.0),
             "Tier 1: Physical IoT Field Layer",
             [
                 "Soil Moisture Sensors (FDR) in Sectors A1-A5.",
                 "Optical NPK Chemical Probes measuring nutrients.",
                 "Precision Solenoid Valve Actuators for automated drip.",
                 "Multispectral Drone Imagery for NDVI indexing.",
                 "Central LoRaWAN 868MHz Gateway Base Station."
             ])

    add_card(s4, Inches(4.8), Inches(1.6), Inches(3.7), Inches(5.0),
             "Tier 2: AWS Cloud Infrastructure",
             [
                 "Provisioned Declaratively via Terraform.",
                 "Dedicated VPC (10.0.0.0/16) & Public Subnet.",
                 "Internet Gateway (IGW) with custom route tables.",
                 "Hardened Security Group: Ports 80, 3000, 443 & 22.",
                 "Ubuntu 22.04 LTS EC2 Host with Docker CLI & ECR Auth."
             ])

    add_card(s4, Inches(8.8), Inches(1.6), Inches(3.7), Inches(5.0),
             "Tier 3: Collaborative Web Platform",
             [
                 "Hardened Express.js REST API with Helmet security.",
                 "Dynamic SVG/HTML Gantt Chart Engine.",
                 "Real-time WebSocket & simulated IoT telemetry stream.",
                 "Collaborative Activity Feed and Role Switcher.",
                 "DevSecOps Audit Center displaying live scan posture."
             ])

    # -------------------------------------------------------------
    # SLIDE 5: DevSecOps CI/CD Workflow & Pipeline
    # -------------------------------------------------------------
    s5 = prs.slides.add_slide(blank_layout)
    add_header(s5, "DevSecOps CI/CD Pipeline Automation (Jenkins)")

    add_card(s5, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Pipeline Stages (1 to 5: Code to SAST)",
             [
                 "Stage 1: Checkout SCM - Webhook trigger clones Git commit.",
                 "Stage 2: Dependencies & Linting - 'npm ci' and 'npm audit' execute dependency integrity check.",
                 "Stage 3: Automated Unit Testing - Node.js native test runner validates API routes & payload handling.",
                 "Stage 4: SonarQube SAST Scan - Analyzes code complexity, security hotspots, and duplication.",
                 "Stage 5: SonarQube Quality Gate - Enforces Rating 'A'; halts pipeline on security flaws."
             ])

    add_card(s5, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "Pipeline Stages (6 to 10: Security to Deploy)",
             [
                 "Stage 6: Docker Image Build - Compiles multi-stage image with non-root user (UID 1001).",
                 "Stage 7: Trivy Vulnerability Scan - Scans filesystem and container image; aborts on Critical CVEs.",
                 "Stage 8: AWS ECR Push - Authenticates Docker CLI and pushes image to Amazon ECR.",
                 "Stage 9: Terraform Ubuntu IaC - Automated 'terraform apply' provisions Ubuntu EC2 with Docker CLI.",
                 "Stage 10: Public IP Verify - Runs ECR container on Ubuntu EC2; probes Public IP on ports 80 & 3000."
             ])

    # -------------------------------------------------------------
    # SLIDE 6: Website Implementation & Collaborative Features
    # -------------------------------------------------------------
    s6 = prs.slides.add_slide(blank_layout)
    add_header(s6, "Website Implementation & Interactive Features")

    add_card(s6, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Core Web Features & Technologies",
             [
                 "Technology Stack: Node.js, Express, Vanilla JS, Bootstrap 5, SVG Gantt rendering, Helmet security.",
                 "Interactive Gantt Timeline: Visual duration bars, progress percentage tracking, and milestone markers.",
                 "Phase & Priority Filtering: Instant filtering across Network, Sensing, Actuation, Drone, and DevSecOps phases.",
                 "RESTful Endpoints: Full CRUD operations for tasks, telemetry feeds, and audit events."
             ])

    add_card(s6, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "Collaboration & Live Telemetry",
             [
                 "Multi-Role Switcher: Seamlessly toggle between Agronomist, DevSecOps Lead, Hardware Specialist, and Farm Lead.",
                 "Live Activity Feed: Real-time logging of schedule modifications, parameter tweaks, and approvals.",
                 "Simulated IoT Telemetry Cards: Live indicators for Soil Moisture %, NPK levels, Gateway SNR, and Solenoid Valve states.",
                 "DevSecOps Modal & SDG 9 Badge: Interactive transparency panels explaining security and sustainability."
             ])

    # -------------------------------------------------------------
    # SLIDE 7: Docker Containerization & Hardening
    # -------------------------------------------------------------
    s7 = prs.slides.add_slide(blank_layout)
    add_header(s7, "Docker Containerization & Image Hardening")

    add_card(s7, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Container Architecture & Multi-Stage Build",
             [
                 "Stage 1 (Builder): Installs production packages with 'npm ci --only=production'.",
                 "Stage 2 (Runner): Minimal Alpine Linux 3.20 base image containing zero unnecessary build tooling.",
                 "Non-Root Privilege Separation: Creates system user 'nodejs' with UID 1001; switches execution away from root.",
                 "OCI Compliant Metadata: Labels document project name, maintainer, SDG 9 alignment, and version."
             ])

    add_card(s7, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "DevSecOps Hardening Outcomes",
             [
                 "Mitigates Container Breakout: Even in event of app compromise, attacker cannot access host kernel as root.",
                 "Integrated Docker Healthcheck: Automated 'wget --spider /api/health' executes every 30 seconds.",
                 "Dramatic Attack Surface Reduction: Base image size reduced to ~120MB, eliminating legacy utilities.",
                 "Zero Unfixed CVEs: Trivy verified zero Critical and zero High vulnerabilities in container image."
             ])

    # -------------------------------------------------------------
    # SLIDE 8: AWS Infrastructure Using Terraform
    # -------------------------------------------------------------
    s8 = prs.slides.add_slide(blank_layout)
    add_header(s8, "AWS Cloud Infrastructure as Code (Terraform)")

    add_card(s8, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Declarative Cloud Resources Provisioned",
             [
                 "Dedicated VPC: '10.0.0.0/16' isolating Smart Agriculture compute from default network.",
                 "Public Subnet: '10.0.1.0/24' hosted in 'us-east-1a' with auto-assign public IP enabled.",
                 "Internet Gateway & Route Table: Custom gateway routing external traffic to web services.",
                 "Ubuntu EC2 Machine: 't3.micro' running Ubuntu 22.04 LTS with Docker CLI & ECR IAM profile.",
                 "Cloud-Init User Data: Installs Docker CLI, logs into ECR, pulls image, and runs on ports 80 & 3000."
             ])

    add_card(s8, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "DevSecOps Least-Privilege Firewall (Security Group)",
             [
                 "Inbound HTTP (Port 80): Open to 0.0.0.0/0 for standard web platform access.",
                 "Inbound App (Port 3000): Open to 0.0.0.0/0 for direct Node.js access on public IP.",
                 "Inbound HTTPS (Port 443): Open to 0.0.0.0/0 for TLS encrypted communication.",
                 "Inbound SSH (Port 22): Admin SSH Access for remote management.",
                 "ECR Authentication: IAM instance profile eliminates hardcoded AWS access keys."
             ])

    # -------------------------------------------------------------
    # SLIDE 9: Security Scan Results & Basic Vulnerability Report
    # -------------------------------------------------------------
    s9 = prs.slides.add_slide(blank_layout)
    add_header(s9, "Security Scanning & Vulnerability Assessment")

    add_card(s9, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "SonarQube SAST & Trivy Scan Results",
             [
                 "SonarQube Quality Gate: PASSED with Rating 'A'.",
                 "SonarQube Security Rating: 'A' (0 Vulnerabilities, 0 Open Hotspots).",
                 "SonarQube Maintainability: 'A' (0 Code Smells after refactoring).",
                 "Code Test Coverage: 92.4% with 5/5 unit tests passing.",
                 "Trivy Container Scan: 0 Critical, 0 High vulnerabilities detected.",
                 "Trivy Filesystem Scan: Clean dependency tree."
             ])

    add_card(s9, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "Vulnerability Remediation Matrix",
             [
                 "CVE-2023-45853 (Critical): Buffer overflow in zlib minizip -> Patched via Alpine 3.20 base update.",
                 "Docker Root Execution (High): Host escape threat -> Remediated via 'USER nodejs' (UID 1001).",
                 "Open Port 22 SSH (High): Remote brute force risk -> Restricted to admin CIDR in Terraform.",
                 "Express Header Disclosure (Medium): Version fingerprinting -> Eliminated via Helmet middleware.",
                 "Payload Flooding (Medium): Resource DoS -> Enforced 10kb JSON body limits on APIs."
             ])

    # -------------------------------------------------------------
    # SLIDE 10: Analysis and Interpretation (20%)
    # -------------------------------------------------------------
    s10 = prs.slides.add_slide(blank_layout)
    add_header(s10, "Analysis & Interpretation of DevSecOps Results")

    add_card(s10, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Pipeline Performance & Test Metrics",
             [
                 "Rapid Feedback Loop: End-to-end pipeline executes in ~4 minutes, providing immediate security feedback.",
                 "Automated Security Gates: Successfully stopped insecure builds during testing when simulated CVE was injected.",
                 "Zero Human Error in Provisioning: Terraform eliminated configuration drift across network & firewall settings.",
                 "High Code Reliability: API test suite verifies health endpoints and rejects malformed payloads."
             ])

    add_card(s10, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "Practical Challenges & Solutions",
             [
                 "Challenge 1: Outdated base Docker images contained legacy package CVEs -> Solved by shifting to hardened Alpine minimal runtime.",
                 "Challenge 2: Multi-disciplinary collaboration friction -> Solved with unified Gantt timeline mapping IoT hardware to software tasks.",
                 "Challenge 3: Security vs Usability -> Implemented automated quality gates so developers do not need manual security reviews."
             ])

    # -------------------------------------------------------------
    # SLIDE 11: Conclusion and Future Scope
    # -------------------------------------------------------------
    s11 = prs.slides.add_slide(blank_layout)
    add_header(s11, "Conclusion & Future Scope")

    add_card(s11, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.0),
             "Project Conclusions",
             [
                 "Demonstrated successful synthesis of IoT precision agriculture project management and DevSecOps best practices.",
                 "Verified complete alignment with UN SDG 9 (Industry, Innovation, and Infrastructure).",
                 "Established reproducible CI/CD pipeline enforcing SonarQube SAST and Trivy vulnerability standards.",
                 "Successfully deployed production-ready web application on AWS EC2 using Terraform IaC."
             ])

    add_card(s11, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.0),
             "Future Scope & Roadmap",
             [
                 "AWS IoT Core Integration: Native MQTT message broker routing directly into DynamoDB time-series tables.",
                 "Predictive Machine Learning: Edge AI yield forecasting embedded directly into milestone Gantt dates.",
                 "Kubernetes & GitOps: Migration to Amazon EKS managed cluster using ArgoCD for declarative GitOps.",
                 "HashiCorp Vault: Dynamic secrets management for rotating LoRaWAN network encryption keys."
             ])

    # -------------------------------------------------------------
    # SLIDE 12: Evidence of Completion & Q&A
    # -------------------------------------------------------------
    s12 = prs.slides.add_slide(blank_layout)
    add_header(s12, "Evidence of Completion & Q&A")

    add_card(s12, Inches(1.5), Inches(1.6), Inches(10.333), Inches(5.0),
             "Verification Artifacts & Submission Deliverables",
             [
                 "GitHub Repository: https://github.com/your-username/agrigantt-iot-devsecops",
                 "Demonstration Video: 4-minute walkthrough showing Docker container build, Jenkins pipeline, SonarQube SAST, Trivy CVE scan, and live Gantt web UI.",
                 "Social Media (LinkedIn) Upload: Demonstration posted without exposed credentials.",
                 "Comprehensive Documentation: Complete formal project report (.docx & Markdown).",
                 "Basic Vulnerability Report: Included with detailed threat analysis and remediation matrix.",
                 "\nThank You! Open to Questions and Faculty Feedback."
             ], border_color=COLOR_PRIMARY)

    # Save presentation
    output_path = os.path.join(os.path.dirname(__file__), "AgriGantt_DevSecOps_Presentation.pptx")
    prs.save(output_path)
    print(f"Presentation saved successfully to: {output_path}")

if __name__ == "__main__":
    build_presentation()
