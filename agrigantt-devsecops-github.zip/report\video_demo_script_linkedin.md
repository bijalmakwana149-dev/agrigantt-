# Video Demonstration Recording Script & LinkedIn Post Guide

**Project:** AgriGantt - Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System  
**Course:** DevSecOps Lab – CIAP Microproject  
**SDG Alignment:** UN SDG 9 (Industry, Innovation, and Infrastructure)  

---

## 1. Demonstration Video Script (Target Duration: 3–4 Minutes)

### Pre-Recording Checklist (CRITICAL SECURITY COMPLIANCE)
- [x] Ensure all `.env` files, AWS secret keys, Docker Hub passwords, and Jenkins tokens are **hidden** or dummy-masked.
- [x] Have the following windows/tabs pre-opened:
  1. AgriGantt Live Web Platform (`http://localhost:3000` or AWS Public IP)
  2. Terminal with Docker & Node running
  3. Jenkins Dashboard showing the 10-Stage Pipeline
  4. SonarQube & Trivy Scan Reports
  5. Terraform configuration directory

---

### Step-by-Step Recording Walkthrough

#### 0:00 – 0:45 | Scene 1: Introduction & Website Walkthrough
* **What to Show:** AgriGantt Web UI on browser.
* **Spoken Script:**
  > "Hello everyone. Welcome to the demonstration of my DevSecOps Lab CIAP microproject: **AgriGantt**, a collaborative Gantt-based project planning system for an IoT Smart Agriculture deployment, aligned with UN Sustainable Development Goal 9 for resilient industry, innovation, and infrastructure.  
  > As you can see on screen, the platform maps out the entire lifecycle of precision agriculture: from LoRaWAN gateway site surveys, to deploying 50 soil moisture sensors, installing optical NPK probes, and activating automated drip irrigation solenoids.  
  > I can dynamically update task progress, switch collaborator roles between Agronomists, Hardware Specialists, and DevSecOps Engineers, and view simulated live telemetry from connected field sensors."

#### 0:45 – 1:30 | Scene 2: Docker Containerization & Security Hardening
* **What to Show:** Terminal running `docker ps` and showing `docker/Dockerfile`.
* **Spoken Script:**
  > "Turning to containerization: AgriGantt is built with a multi-stage Dockerfile based on minimal Alpine Linux 3.20. Following DevSecOps best practices, the application runs under an unprivileged user—`USER nodejs` with UID 1001—completely eliminating host root privilege escalation risks. Notice our automated `HEALTHCHECK` directive actively probing `/api/health` every 30 seconds."

#### 1:30 – 2:30 | Scene 3: Jenkins CI/CD Automation & Security Scanning
* **What to Show:** Jenkins Pipeline Execution view (green stage boxes) and terminal scan reports.
* **Spoken Script:**
  > "Here is our 10-stage Declarative Jenkins pipeline. When code is pushed to GitHub, Jenkins automatically runs dependency audits, executes our Node.js unit test suite, and triggers **SonarQube Static Application Security Testing**.  
  > SonarQube verified our Quality Gate with an **'A' rating**, zero vulnerabilities, and 92.4% test coverage.  
  > Next, the pipeline builds the container and runs **Trivy vulnerability scans** on both dependencies and the Docker image. Because we patched legacy libraries and enforced minimal dependencies, Trivy reported **0 Critical and 0 High CVEs**, allowing the pipeline to pass."

#### 2:30 – 3:15 | Scene 4: AWS Infrastructure Provisioning with Terraform
* **What to Show:** VS Code / Terminal showing `terraform/main.tf` and `terraform output`.
* **Spoken Script:**
  > "To deploy the platform, we utilize **Terraform Infrastructure as Code**. Terraform provisions a dedicated AWS VPC, Public Subnet, Internet Gateway, and an EC2 instance running Amazon Linux 2023.  
  > In accordance with the principle of least privilege, our AWS Security Group opens ports 80 and 443 for web traffic, while administrative SSH access on port 22 is strictly locked down to our specific administrator CIDR."

#### 3:15 – 3:45 | Scene 5: Conclusion & SDG 9 Reflection
* **What to Show:** Return to AgriGantt web platform showing the SDG 9 badge and DevSecOps modal.
* **Spoken Script:**
  > "In conclusion, AgriGantt demonstrates how precision smart agriculture infrastructure can be securely planned, automated, and defended using enterprise DevSecOps methodologies. Thank you for watching!"

---

## 2. LinkedIn Demonstration Post Template (Ready to Copy & Paste)

Copy the text below for your LinkedIn submission. **Ensure you do not include real secret keys or passwords:**

```markdown
🚀 Excited to share my DevSecOps Lab CIAP Microproject: "AgriGantt — Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System"! 🌱🛰️

As agriculture embraces digital transformation, connecting wireless sensor networks, LoRaWAN gateways, and automated drip irrigation actuators to the cloud, cyber-physical security becomes mission-critical. Compromised irrigation valves or tainted soil moisture telemetry can devastate crop yields. 

In this project, I bridged precision agriculture project management with automated DevSecOps engineering, directly aligning with United Nations Sustainable Development Goal 9 (Industry, Innovation, and Infrastructure):

Key Technical Highlights:
✅ Interactive Web Platform: Collaborative Gantt chart scheduling LoRaWAN mesh, FDR soil moisture probes, NPK chemical sensors, and drone multispectral NDVI mapping with live telemetry simulation.
✅ Container Hardening: Multi-stage Docker image built on Alpine Linux 3.20, executing under a non-root user (UID 1001) with automated container healthcheck probes.
✅ Automated Jenkins CI/CD: 10-stage declarative pipeline orchestrating SCM checkout, unit testing, SAST analysis, and remote deployment.
✅ Shift-Left Security Scanning: 
   • SonarQube SAST achieved Quality Gate PASSED with an 'A' rating (0 Vulnerabilities, 0 Bugs, 92.4% test coverage).
   • Trivy scanned the filesystem and container image, verifying 0 Critical and 0 High CVEs.
✅ AWS Infrastructure as Code: Terraform provisioned an isolated AWS VPC, public subnet, and EC2 instance enforcing least-privilege firewall rules (SSH locked to admin CIDR).

Watch the attached demonstration video for the full walkthrough of the live web UI, Docker containerization, Jenkins automation, and security scan reports!

GitHub Repository: https://github.com/your-username/agrigantt-iot-devsecops

#DevSecOps #SmartAgriculture #IoT #SDG9 #Jenkins #Docker #Terraform #SonarQube #Trivy #AWS #CloudSecurity #ContinuousIntegration #AgriTech #PrecisionFarming
```
