# AgriGantt DevSecOps Jenkins Launcher for Docker Desktop
Write-Host "=======================================================" -ForegroundColor Green
Write-Host " Starting Jenkins CI/CD Container on Docker Desktop..." -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Green

# Ensure docker volume exists
docker volume create jenkins_home | Out-Null

# Stop any older container if present
docker rm -f jenkins_server 2>$null | Out-Null

# Run Jenkins container with Docker socket mount
docker run -d `
  --name jenkins_server `
  --restart unless-stopped `
  -p 8080:8080 `
  -p 50000:50000 `
  -v jenkins_home:/var/jenkins_home `
  -v //var/run/docker.sock:/var/run/docker.sock `
  jenkins/jenkins:lts

Write-Host "Waiting 20 seconds for Jenkins to generate credentials..." -ForegroundColor Yellow
Start-Sleep -Seconds 20

# Retrieve Initial Admin Password
$adminPass = docker exec jenkins_server cat /var/jenkins_home/secrets/initialAdminPassword 2>$null
Write-Host "-------------------------------------------------------" -ForegroundColor Cyan
Write-Host " Jenkins Web UI: http://localhost:8080" -ForegroundColor Cyan
Write-Host " Initial Admin Password:" -ForegroundColor Yellow
Write-Host "$adminPass" -ForegroundColor Green
Write-Host "-------------------------------------------------------" -ForegroundColor Cyan
