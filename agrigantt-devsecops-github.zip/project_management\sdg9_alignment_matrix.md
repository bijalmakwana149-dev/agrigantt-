# SDG 9: Industry, Innovation, and Infrastructure Alignment Matrix

**Project:** AgriGantt - Gantt-Based Collaborative Project Plan for an IoT Smart Agriculture System  
**Framework:** United Nations Sustainable Development Goals (SDG 9)  
**Evaluated by:** DevSecOps Lab CIAP Microproject Team  

---

## 1. Context and Strategic Relevance

Sustainable Development Goal 9 seeks to **"Build resilient infrastructure, promote inclusive and sustainable industrialization, and foster innovation."** Traditional agriculture frequently relies on manual, unmetered flood irrigation, arbitrary chemical fertilizer dispersal, and isolated on-premise operational silos. These practices waste up to 40% of agricultural freshwater and lead to substantial nutrient runoff that degrades soils and water bodies.

Simultaneously, the modernization of agriculture introduces complex digital infrastructure—wireless IoT sensor meshes, cloud analytics, and automated actuators. Without strict DevSecOps governance, precision agriculture networks become vulnerable to cyber attacks, tampering, and service downtime that endanger food supply stability.

AgriGantt addresses these challenges by harmonizing sustainable precision agriculture infrastructure planning with rigorous DevSecOps engineering.

---

## 2. Detailed Alignment Matrix

| SDG 9 Target | Target Description | AgriGantt Solution Feature | Measurable Impact & Key Performance Indicator (KPI) |
| :--- | :--- | :--- | :--- |
| **Target 9.1** | Develop quality, reliable, sustainable and resilient infrastructure to support economic development and human well-being. | Decoupled LoRaWAN 868MHz mesh architecture with autonomous solar-powered soil moisture and temperature nodes. | **99.8% Field Uptime:** Wireless mesh maintains telemetry even during intermittent rural cellular outages; decentralized edge gateways buffer data locally. |
| **Target 9.4** | Upgrade infrastructure and retrofit industries to make them sustainable, with increased resource-use efficiency and greater adoption of clean and environmentally sound technologies. | Real-time Gantt tracking of closed-loop precision drip irrigation solenoid actuators and optical NPK chemical dosing sensors. | **38% Water Conservation & 25% Fertilizer Reduction:** Drip irrigation triggers strictly when soil moisture drops below root-zone threshold, preventing excess water extraction. |
| **Target 9.5** | Enhance scientific research, upgrade technological capabilities of industrial sectors, and foster technological innovation in developing countries. | Implementation of automated "Shift-Left" DevSecOps pipeline embedding SonarQube SAST, Trivy CVE container scanning, and Terraform AWS Cloud IaC. | **Zero Critical Vulnerabilities (0 CVE):** 100% automated security gate enforcement; eliminates remote exploit risks on cloud and field infrastructure. |

---

## 3. DevSecOps Contribution to Sustainable Infrastructure

1. **Environmental Resilience via Infrastructure as Code (IaC):**  
   Terraform scripts allow on-demand spinning up and teardown of cloud monitoring clusters, preventing idle compute waste and minimizing carbon footprint.
2. **Zero-Trust Operational Integrity:**  
   By enforcing non-root container execution (UID 1001) and restricting AWS security group ingress, AgriGantt ensures unauthorized entities cannot manipulate automated irrigation valves or alter crop telemetry.
